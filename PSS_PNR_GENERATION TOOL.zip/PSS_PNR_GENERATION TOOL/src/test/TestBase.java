package test;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

public class TestBase {

    //Create Driver
    //Load file
    public static WebDriver driver;
    public static Properties prop=new Properties();

    //create driver
    public static void createdriverfunction(){
        System.setProperty("webdriver.chrome.driver","C:\\Users\\S940089\\Documents\\chromedriver_win32\\chromedriver.exe");
        driver=new ChromeDriver();
        driver.manage().window().maximize();
        driver.manage().deleteAllCookies();
        driver.manage().timeouts().pageLoadTimeout(20,TimeUnit.SECONDS);
        driver.manage().timeouts().implicitlyWait(100,TimeUnit.SECONDS);
        driver.get(prop.getProperty("URL"));
    }

    //load properties
    public TestBase() {
        File file = new File("C:\\Users\\S940089\\IdeaProjects\\PSS_PNR_GENERATION TOOL\\src\\config.properties");
        FileInputStream fileinput = null;
        try {
            fileinput = new FileInputStream(file);
        } catch (FileNotFoundException e) {
            System.out.println("File Not found");
        }

        try {
            prop.load(fileinput);
        } catch (IOException e) {
            System.out.println("IOException");
        } finally {
            if (null != fileinput) {
                try {
                    fileinput.close();
                } catch (IOException e) {
                    System.out.print("File Close IOException");
                }
            }
        }
    }

    //quit driver
    public void closeDriver()
    {
        driver.quit();
    }
}
