package pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import test.TestBase;

public class LoginPage extends TestBase {

@FindBy(xpath = "//*[@id=\"standard-disabled\"]")
WebElement username;

@FindBy(xpath = "//*[@id=\"standard-password-input\"]")
WebElement password;

@FindBy(xpath = "/html/body/div[2]/div[2]/div/div[3]/button/span[1]")
WebElement loginbutton;

@FindBy(xpath = "//*[@id=\"app\"]/section/section/section/div[1]/h3/div")
WebElement afterlogintext;

    public LoginPage()
    {
        PageFactory.initElements(driver, this);
    }

    public GenPnrPage loginaction(String un,String ps){
        this.username.sendKeys(un);
        this.password.sendKeys(ps);
        this.loginbutton.click();
        return new GenPnrPage();
    }
}
