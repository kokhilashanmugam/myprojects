package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import test.TestBase;
import java.util.concurrent.TimeUnit;

public class GenPnrPage extends TestBase {
    JavascriptExecutor ja = (JavascriptExecutor) driver;

    @FindBy(xpath = "//*[@id=\"app\"]/section/div/div/header/div[1]/div[2]/div[1]")
    WebElement booking;

    @FindBy(xpath = "//*[@id=\"app\"]/section/div/div/header/div[1]/div[2]/div[2]/ul/li[1]")
    WebElement pnrcreation;

    @FindBy(xpath = "//*[@id=\"app\"]/section/section/section/div[2]/div/div/div/div")
    WebElement env;

    @FindBy(xpath = "//*[@id=\"menu-dropdown-booking00001\"]/div[2]/ul/li[2]")
    WebElement UAT;

    @FindBy(className = "jss236 jss239 jss199 jss250")
    WebElement pnrtypeclassname;

    @FindBy(xpath = "//*[@id=\\\"app\\\"]/section/section/section/div[3]/div")
    WebElement pnr_type;

    @FindBy(xpath = "//*[@id=\"menu-dropdown-booking00004\"]/div[2]/ul/li[1]")
    WebElement revenue;

    @FindBy(xpath = "//*[@id=\"app\"]/section/section/section/div[4]/div")
    WebElement cabinclass;

    @FindBy(xpath = "//*[@id=\"menu-dropdown-booking00022\"]/div[2]/ul/li[1]")
    WebElement Y_cabin_path;

    @FindBy(xpath = "//*[@id=\"menu-dropdown-booking00022\"]/div[2]/ul/li[2]")
    WebElement J_cabin_path;

    @FindBy(xpath = "//*[@id=\"menu-dropdown-booking00022\"]/div[2]/ul/li[3]")
    WebElement F_cabin_path;

    @FindBy(id = "text-field-booking00059")
    WebElement noofpnr;

    @FindBy(id = "text-field-booking00060")
    WebElement flightnumber;

    @FindBy(id = "text-field-booking00061")
    WebElement departuredate;

    @FindBy(id = "text-field-booking00062")
    WebElement route;

    @FindBy(id = "text-field-booking00063")
    WebElement pos;

    @FindBy(id = "text-field-booking00064")
    WebElement adultcount;

    @FindBy(id = "text-field-booking00065")
    WebElement childcount;

    @FindBy(id = "text-field-booking00066")
    WebElement infantonlap;

    @FindBy(id = "text-field-booking00067")
    WebElement infantonseat;

    @FindBy(xpath = "//*[@id=\"app\"]/section/section/section/div[29]/label/span[1]/span[1]/input")
    WebElement issueticketcheckbox;

    @FindBy(className = "jss272")
    WebElement checkboxclick;

    @FindBy(className = "jss34 jss8 jss19 jss20 jss22 jss23")
    WebElement submit;

    @FindBy(xpath = "/html/body/div[3]/div[2]/div/div[2]/div/div/table/tbody/tr[1]/th[1]")
    WebElement PNRans;

    @FindBy(xpath = "/html/body/div[3]/div[2]/div/div[2]/div/div/table/tbody/tr[2]/th[2]")
    WebElement lastname;

    public GenPnrPage() {
        PageFactory.initElements(driver, this);
    }

    public void button_hover(){
        //driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        Actions act=new Actions(driver);
        WebDriverWait wait = new WebDriverWait(driver,30);
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"app\"]/section/div/div/header/div[1]/div[2]/div[1]")));
        act.clickAndHold(booking).build().perform();
        driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
    }

    public void firstrow() throws NullPointerException{
        pnrcreation.click();
        env.click();
        UAT.click();
        ja.executeScript("document.getElementsByClassName('jss236 jss239 jss199 jss250')[1].click()");
        revenue.click();
        driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
    }

    public void cabin_class() throws NullPointerException{
        ja.executeScript("document.getElementsByClassName('jss236 jss239 jss199 jss250')[2].click()");
        if(prop.getProperty("cabin_input").equalsIgnoreCase("Y")){
            Y_cabin_path.click();
        }
        else if(prop.getProperty("cabin_input").equalsIgnoreCase("J")){
            J_cabin_path.click();
        }
        else if(prop.getProperty("cabin_input").equalsIgnoreCase("F")){
            F_cabin_path.click();
        }
    }

    public void secondrow(){
        //number of pnr
        noofpnr.sendKeys(Keys.BACK_SPACE);
        noofpnr.sendKeys(prop.getProperty("noofpnr_input"));
        //flight number
        flightnumber.sendKeys(prop.getProperty("flightnumber_input"));
        //departure date
        departuredate.sendKeys(prop.getProperty("departure_input"));
    }

    public void thirdrow(){
        //route
        route.sendKeys(prop.getProperty("route_input"));
        //pos
        pos.sendKeys(prop.getProperty("pos_input"));
        //adult count
        adultcount.sendKeys(prop.getProperty("adultcount_input"));
        //child count
        childcount.sendKeys(Keys.BACK_SPACE);
        childcount.sendKeys(prop.getProperty("childcount_input"));
        //infant on lap
        infantonlap.sendKeys(Keys.BACK_SPACE);
        infantonlap.sendKeys(prop.getProperty("infantonlap_input"));
        //infant on seat
        infantonseat.sendKeys(Keys.BACK_SPACE);
        infantonseat.sendKeys(prop.getProperty("infantonseat_input"));
    }

    public void generate(){
        //issue ticket checkbox
        if(!issueticketcheckbox.isSelected()){
            ja.executeScript("document.getElementsByClassName('jss272')[0].click();");
        }
        ja.executeScript("window.scrollBy(0,500)");

        //submit
        ja.executeScript("document.getElementsByClassName('jss34 jss8 jss19 jss20 jss22 jss23')[0].click();");
        driver.manage().timeouts().implicitlyWait(200, TimeUnit.SECONDS);
    }

    public void getdata(){
        String PNR=PNRans.getText();
        String LAST_NAME=lastname.getText();
        System.out.println("PNR: "+PNR);
        System.out.println("LAST NAME: "+LAST_NAME);
    }
}
