package testcases;

import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import pages.GenPnrPage;
import pages.LoginPage;

import test.TestBase;
import java.util.concurrent.TimeUnit;

public class PNRGenerationTest extends TestBase {

LoginPage loginPage;
GenPnrPage genpnrpage;

    public
    PNRGenerationTest(){
    }

    @BeforeTest
    public void gensetup() {
        createdriverfunction();
        this.loginPage = new LoginPage();
        //driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
    }

    @Test(priority = 1)
    public void genpnraction(){
        this.genpnrpage = this.loginPage.loginaction(prop.getProperty("username"), prop.getProperty("password"));
        this.genpnrpage.button_hover();
        this.genpnrpage.firstrow();
        this.genpnrpage.cabin_class();
        this.genpnrpage.secondrow();
        this.genpnrpage.thirdrow();
        this.genpnrpage.generate();
        this.genpnrpage.getdata();
    }

    @AfterTest
    public void close(){
        //closeDriver();
    }
}
