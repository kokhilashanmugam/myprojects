package testcases;

import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import pages.GenPnrPage;
import pages.LoginPage;

import test.TestBase;

public class LoginTest extends TestBase {

    LoginPage loginpage;
    GenPnrPage genpnrpage;

    public LoginTest(){
    }

    @BeforeTest
    public void setup(){
        createdriverfunction();
        this.loginpage=new LoginPage();
    }

    @Test(priority = 1)
    public void loginTest() {
        this.genpnrpage=this.loginpage.loginaction(prop.getProperty("username"),prop.getProperty("password"));
    }

    @AfterTest
    public void close(){
        //closeDriver();
    }
}
