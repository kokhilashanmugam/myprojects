import com.packages.TestBaseInitialization;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class MainRestTest_PNR extends TestBaseInitialization {
    MainRestTest_PNR mainRestTest_pnr;

    @BeforeTest
    public void connectionsetup(){
        mainRestTest_pnr =new MainRestTest_PNR();
        try {
            mainRestTest_pnr.setup();           //calling TestBaseInitialization
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Test
    public void restAPI_Pnr()
    {
        testAPI();
    }

}