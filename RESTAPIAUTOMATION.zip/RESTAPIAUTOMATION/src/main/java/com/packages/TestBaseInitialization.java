package com.packages;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.json.simple.JSONArray;
import org.json.simple.parser.ParseException;

import java.io.*;
import java.lang.String;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import java.io.File;
import java.util.*;

import static io.restassured.RestAssured.*;
import static io.restassured.path.json.JsonPath.from;
import static java.lang.System.*;
import static org.apache.commons.lang3.StringUtils.isNumeric;

public class TestBaseInitialization {

    public String CONTEXT_PATH = "/tdm/booking/creationNew";
    ArrayList<String> nameslist = new ArrayList<String>();

    public  void setup() throws Exception {
        RestAssured.baseURI = "http://dolnxprodvm1018:8785";
        RequestSpecification request = given();
    }

    public void testAPI() {
        try {
            //setup();
            String token = "czk0MDA4OQ==";
            String Json = "{\n" +
                    "  \"enivironment\": \"UAT\",\n" +
                    "  \"pnrType\": \"STAFF_PNR\",\n" +
                    "  \"cabinClass\": \"Y\",\n" +
                    "  \"offLinePayment\": \"\",\n" +
                    "  \"staffTicketType\": \"CAT A Subload\",\n" +
                    "  \"noOfPnr\": \"3\",\n" +
                    "  \"flightNumber\": \"EK0500\",\n" +
                    "  \"departureDate\": \"14MAY2020\",\n" +
                    "  \"route\": \"DXB-BOM\",\n" +
                    "  \"pointOfSale\": \"DXB\",\n" +
                    "  \"adultPaxCount\": \"2\",\n" +
                    "  \"childpaxcount\": \"2\",\n" +
                    "  \"infantonlappaxcount\": \"0\",\n" +
                    "  \"infantonseatpaxcount\": \"0\",\n" +
                    "  \"ffp\": \"\",\n" +
                    "  \"personId\": \"\",\n" +
                    "  \"mobileNumber\": \"\",\n" +
                    "  \"emailId\": \"\",\n" +
                    "  \"milesToSpend\": \"\",\n" +
                    "  \"specialSSR\": \"\",\n" +
                    "  \"mealssrindicator\": \"\",\n" +
                    "  \"formOfPayment\": \"\",\n" +
                    "  \"ccType\": \"\",\n" +
                    "  \"ccNumber\": \"\",\n" +
                    "  \"ccExpiry\": \"\",\n" +
                    "  \"issueeticketindicator\": \"true\",\n" +
                    "  \"holdMyFare\": \"false\",\n" +
                    "  \"docSSR\": \"\"\n" +
                    "}\n";

            Response response;
            response = given()
                    .header("Authorization", token)
                    .contentType("application/json")
                    .accept("application/json")
                    .body(Json).
                            when()
                    .post(CONTEXT_PATH).
                            then()
                    .statusCode(200).contentType("application/json").extract().response();

            String jsonasstring = response.asString();
            out.println(jsonasstring);
            validateresponse(jsonasstring);
        } catch (AssertionError e) {
            out.println("Bad response/request");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void validateresponse(String responseasstring){
        JSONParser parse = new JSONParser();
        try {
            JSONObject obj = (JSONObject) parse.parse(responseasstring);
            JSONArray details = (JSONArray) obj.get("Details");
            for (int i = 0; i < details.size(); i++) {
                JSONObject detailsobject = (JSONObject) details.get(i);
                out.println("PNR NUMBER: " + detailsobject.get("pnrNumber"));
                JSONArray sepname = (JSONArray) detailsobject.get("fullNameAndTickets");
                out.println("COMPLETE PAX DETAILS:");
                for (int j = 0; j < sepname.size(); j++) {
                    out.println(sepname.get(j));
                    nameslist.add((String) sepname.get(j));
                }
            }
            splitnames(nameslist);
        } catch (ParseException e) {
            e.printStackTrace();
        }
    }

    public void splitnames(ArrayList<String> array) {
        ArrayList<String> splittednames = new ArrayList<String>();
        out.println("PAX NAMES:");
        if (array == null) {
            out.println("Names list is empty");
        } else {
            for (int z = 0; z < array.size(); z++) {
                splittednames.addAll(Arrays.asList(array.get(z).split("-")[0]));
            }
        }
        printpaxnames(splittednames);
    }

    public void printpaxnames(ArrayList<String> paxlist) {
        for (int a = 0; a < paxlist.size(); a++) {
            out.println(paxlist.get(a));
        }
    }
}


